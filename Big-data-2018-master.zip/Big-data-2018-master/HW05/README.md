## 利用機器學習的排名
![img](https://github.com/wellgary/Big-data-2018/blob/master/HW03/%E6%8E%92%E5%90%8D.png)

## 利用深度學習的排名
![img](https://github.com/wellgary/Big-data-2018/blob/master/HW05/kaggle2.png)

## 準確率上升了2%
