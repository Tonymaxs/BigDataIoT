## kaggle排名
![img](https://github.com/wellgary/Big-data-2018/blob/master/HW03/%E6%8E%92%E5%90%8D.png)
